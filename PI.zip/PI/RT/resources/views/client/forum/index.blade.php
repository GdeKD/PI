@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <!-- nampilin create kalo login -->
        @if (Route::has('login'))
          <div class="card border-danger card-body">
            <h3 class="card-title">Masukan Topik Diskusi</h3>
            <p class="card-text">Untuk memasukan Topik Diskusi anda harus masuk dengan akun situs ini</p>
            @auth
              <a href="{{ url('/forums/create') }}" class="btn btn-danger">Buat Topik Diskusi</a>
            @endauth
          </div>
        @endif
      </div>
        <div class="col-md-7">
            <div class="card border-primary">
                <div class="card-header border-primary">

                  <h2>
                    <u>Forum Warga</u>
                  </h2>

                </div>

                <div class="card-body ">
                  @if (session('msg'))
                      <div class="alert alert-success">
                          {{ session('msg') }}
                      </div>
                  @elseif (session('redmsg'))
                      <div class="alert alert-danger">
                        {{session('redmsg')}}
                  </div>
                  @endif

                    @foreach ($forums as $forum)
                    <div class="">
                      <h4 class="card-title">{{$forum->judul}}</h4>
                      <div class="row justify-content-between">
                        <div class="col-md-auto">
                          <p>diunggah oleh {{$forum->user['name']}}</p>
                        </div>
                        <div class="col-md-auto">
                          <a href="forum/{{$forum->slug}}" class=" text-right btn btn-primary btn-sm">Lihat selengkapnya</a>
                        </div>
                      </div>
                      <hr>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
