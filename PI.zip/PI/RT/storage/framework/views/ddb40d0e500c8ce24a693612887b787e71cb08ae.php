<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <!-- nampilin create kalo login -->
        <?php if(Route::has('login')): ?>
          <div class="card border-danger card-body">
            <h3 class="card-title">Masukan Topik Diskusi</h3>
            <p class="card-text">Untuk memasukan Topik Diskusi anda harus masuk dengan akun situs ini</p>
            <?php if(auth()->guard()->check()): ?>
              <a href="<?php echo e(url('/forums/create')); ?>" class="btn btn-danger">Buat Topik Diskusi</a>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
        <div class="col-md-7">
            <div class="card border-primary">
                <div class="card-header border-primary">

                  <h2>
                    <u>Forum Warga</u>
                  </h2>

                </div>

                <div class="card-body ">
                  <?php if(session('msg')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('msg')); ?>

                      </div>
                  <?php elseif(session('redmsg')): ?>
                      <div class="alert alert-danger">
                        <?php echo e(session('redmsg')); ?>

                  </div>
                  <?php endif; ?>

                    <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                      <h4 class="card-title"><?php echo e($forum->judul); ?></h4>
                      <div class="row justify-content-between">
                        <div class="col-md-auto">
                          <p>diunggah oleh <?php echo e($forum->user['name']); ?></p>
                        </div>
                        <div class="col-md-auto">
                          <a href="forum/<?php echo e($forum->slug); ?>" class=" text-right btn btn-primary btn-sm">Lihat selengkapnya</a>
                        </div>
                      </div>
                      <hr>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>