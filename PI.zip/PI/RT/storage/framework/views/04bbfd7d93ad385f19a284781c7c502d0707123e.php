<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-primary">
                <div class="card-header border-primary" ><h2 style="text-align: center"><u>Buat Topik Diskusi</u></h2>
                <p class="card-subtitle">Silahkan membuat topik diskusi yang anda ingin ungkapkan kepada sesama warga.
                  <br>Mohon gunakan bahasa yang sopan.
                </p>
                </div>

                <div class="card-body">
                  <!-- Form -->
                  <form class="" action="/forum" method="post">
                    <div class="form-group">
                      <label for="title">Judul Diskusi</label>
                      <input type="text" name="title" class="form-control" placeholder="tulis judul di sini" value="<?php echo e(old('title')); ?>">
                    </div>
                    <div class="form-group">
                      <label for="konten">Isi Diskusi</label>
                      <textarea id="WYSIWYG" name="konten" class="form-control" rows="8" cols="80"><?php echo e(old('konten')); ?></textarea>
                    </div>

                    <?php echo e(csrf_field()); ?>


                    <button type="submit" class="btn btn-default btn-block btn-outline-primary">Tampilkan Topik Diskusi Ini</button>
                  </form>
                  <!-- Form -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>