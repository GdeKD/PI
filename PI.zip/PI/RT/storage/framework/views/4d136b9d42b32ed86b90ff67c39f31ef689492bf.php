<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <?php if(session('msg')): ?>
          <div class="alert alert-success">
            <?php echo e(session('msg')); ?>

          </div>
          <?php elseif(session('redmsg')): ?>
          <div class="alert alert-danger">
            <?php echo e(session('redmsg')); ?>

          </div>
          <?php endif; ?>
          
            <div class="card">


              <div class="card-body">
                  <h4 class="card-title"><?php echo e($forum->judul); ?></h4>
                  <hr>
                  <div class="card-text">
                    <div class="row justify-content-between">
                      <div class="col-md-auto">
                        <p>oleh <?php echo e($forum->user->name); ?></p>
                        <p><?php echo $forum->konten; ?></p>
                      </div>
                      <div class="col-md-auto text-right">
                        <p><?php echo e($forum->updated_at); ?></p>
                      </div>
                    </div>

                  </div>
                  <?php if($forum->owner()): ?>
                  <div class="row">
                    <div class="col-md-auto">
                      <p><a href="<?php echo e(url('/forum')); ?>" class="btn btn-outline-primary"><< Daftar Topik</a></p>
                    </div>
                    <div class="col-md-auto">

                    <a href="/forum/<?php echo e($forum->id); ?>/edit" class="btn btn-outline-warning">Edit Topik</a>
                    </div>
                    <div class="col-md-auto">
                    <form class="" action="/forum/<?php echo e($forum->id); ?>" method="post">
                      <?php echo e(csrf_field()); ?>


                      <!-- ngasih tau kalo ini form DELETE -->
                      <input type="hidden" name="_method" value="DELETE">
                      <!-- input ini aja -->

                      <button type="submit" class="btn btn-outline-danger">Hapus Topik</button>
                    </form>
                    </div>
                    <?php endif; ?>
                </div>
              </div>

          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>