<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

              <h2 class="card-header">Daftar Berita</h2>

                <div class="card-body">
                    <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                    <?php elseif(session('redmsg')): ?>
                        <div class="alert alert-danger">
                          <?php echo e(session('redmsg')); ?>

                    </div>
                    <?php endif; ?>

                    <table style="width: 80%;">
                      <tr>
                        <th>Judul Berita</th>
                        <th>Tanggal publiskasi</th>
                        <th>Pemublikasi</th>
                      </tr>
                    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                        <td><a href="<?php echo e($announcement->slug); ?>"><?php echo e($announcement->judul); ?></a></td>
                        <td><?php echo e($announcement->updated_at); ?></td>
                        <td><?php echo e($announcement->user->name); ?></td>
                        <?php if($announcement->owner()): ?>
                          <td>
                            <a href="/admin/berita/<?php echo e($announcement->id); ?>/edit" class="btn btn-outline-warning btn-sm" active>edit</a>
                          </td>
                          <!-- <td>
                            <form class="" action="/<?php echo e($announcement->id); ?>" method="post">
                              <?php echo e(csrf_field()); ?>


                              <input type="hidden" name="_method" value="DELETE">

                              <button type="submit" class="btn btn-outline-danger btn-sm">delete</button>
                            </form>
                          </td> -->
                        <?php endif; ?>
                      </tr>
                    </tbody>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>