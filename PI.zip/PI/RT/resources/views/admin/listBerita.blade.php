@extends('layouts.dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

              <h2 class="card-header">Daftar Berita</h2>

                <div class="card-body">
                    @if (session('msg'))
                        <div class="alert alert-success">
                            {{ session('msg') }}
                        </div>
                    @elseif (session('redmsg'))
                        <div class="alert alert-danger">
                          {{session('redmsg')}}
                    </div>
                    @endif

                    <table style="width: 80%;">
                      <tr>
                        <th>Judul Berita</th>
                        <th>Tanggal publiskasi</th>
                        <th>Pemublikasi</th>
                      </tr>
                    @foreach ($announcements as $announcement)
                    <tbody>
                      <tr>
                        <td><a href="{{$announcement->slug}}">{{$announcement->judul}}</a></td>
                        <td>{{$announcement->updated_at}}</td>
                        <td>{{$announcement->user->name}}</td>
                        @if($announcement->owner())
                          <td>
                            <a href="/admin/berita/{{$announcement->id}}/edit" class="btn btn-outline-warning btn-sm">edit</a>
                          </td>
                          <!-- <td>
                            <form class="" action="/{{$announcement->id}}" method="post">
                              {{ csrf_field() }}

                              <input type="hidden" name="_method" value="DELETE">

                              <button type="submit" class="btn btn-outline-danger btn-sm">delete</button>
                            </form>
                          </td> -->
                        @endif
                      </tr>
                    </tbody>

                    @endforeach
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
