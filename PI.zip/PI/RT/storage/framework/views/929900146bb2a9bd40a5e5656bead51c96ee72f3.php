<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-primary">
                <h2 class="card-header  text-white bg-primary">Berita Terbaru</h2>
                <div class="card-body">
                    <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                    <?php elseif(session('redmsg')): ?>
                        <div class="alert alert-danger">
                          <?php echo e(session('redmsg')); ?>

                    </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                      <p style="text-align:right">
                        <?php if($announcement->baru()): ?>
                          <span class="badge badge-info">Berita Baru!</span>
                        <?php elseif($announcement->diubah()): ?>
                          <span class="badge badge-warning">Berita diperbarui!</span>
                        <?php endif; ?>
                        <?php echo e($announcement->updated_at); ?>

                      </p>
                      <h4  class="card-title text-center" ><?php echo e($announcement->judul); ?></h4>
                      <p class="lead"><?php echo $announcement->konten; ?></p>
                      <hr>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-3">
          <div class="card border-danger">
            <div class="card-header">
              <h3>Ini Isi Apaan Kek Biar Rame</h3>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>