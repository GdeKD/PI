<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use App\Announcement;
use App\User;

class beritaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $announcements = Announcement::orderBy('updated_at','desc')->get();
        return view('client.berita',compact('announcements'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.newsInsertion');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->input());
        $slug = str_slug($request->title,'-');
        if( Announcement::where('slug',$slug)->first()!=null)
        $slug = $slug.'-'.time();

        $announcements = Announcement::create([
          'judul' => $request->title,
          'slug' => $slug,
          'konten' => $request->konten,
          'userid' =>auth::user()->id
        ]);
        return redirect('/berita')->with('msg','Berita diunggah.');
    }

    /**
     * Display the specified resource.
     *
     * @param  string $slug
     * @return \Illuminate\Http\Response
     */
    public function show($slug)
    {
      $announcement = Announcement::where('slug',$slug)->first();
      if (empty($announcement))
      App::abort(404, 'message');
      return view('admin.beritaShow',compact('announcement'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $announcement=Announcement::findOrFail($id);
        return view('admin.newsEdit', compact('announcement'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $announcement = Announcement::findOrFail($id);
        if ($announcement->owner()) {
          // code...
          $announcement->update([
            'judul' => $request->title,
            'konten' => $request->konten,
          ]);
        }
        else {
          abort(404, 'jancok!');
        }
        return redirect('admin/berita/list')->with('msg','Berita telah dipebarui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $announcement=Announcement::findOrFail($id);
        if ($announcement->owner()) {
          $announcement->delete();
        }
        else abort(403);
        return redirect('admin/berita/list')->with('redmsg','Berita dihapus.');
    }

    public function list(){
      $announcements = Announcement::orderBy('updated_at','desc')->get();
      return view('admin.listBerita',compact('announcements'));
    }
}
