<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <br>
                <div class="card-header" style="text-align: center"><?php echo e(__('Form Pembuatan Berita')); ?></div>
                <hr>
                <div class="card-body">
                  <!-- Form -->
                  <form class="" action="/admin/berita" method="post">
                    <div class="form-group">
                      <label for="title">Judul Berita</label>
                      <input type="text" name="title" class="form-control" placeholder="tulis judul di sini" value="<?php echo e(old('title')); ?>">
                    </div>
                    <div class="form-group">
                      <label for="konten">Isi Berita</label>
                      <textarea id="WYSIWYG" name="konten" class="form-control" rows="8" cols="80"><?php echo e(old('konten')); ?></textarea>
                    </div>

                    <?php echo e(csrf_field()); ?>


                    <button type="submit" class="btn btn-default btn-block btn-outline-primary">Tampilkan Berita</button>
                  </form>
                  <!-- Form -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>