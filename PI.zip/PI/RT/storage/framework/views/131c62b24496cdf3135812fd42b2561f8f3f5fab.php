<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
              <br>
                <div class="card-header" style="text-align: center">
                  <h3><?php echo e($announcement->judul); ?></h3>
                </div>
                <hr>
                <div class="card-body">
                  <p><?php echo $announcement->konten; ?></p>
                  <?php if($announcement->owner()): ?>
                  <span>
                    <a href="/admin/berita/<?php echo e($announcement->id); ?>/edit" class="btn btn-outline-warning btn-sm btn-active">edit</a>
                  </span>
                  <span>
                      <form class="" action="<?php echo e($announcement->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>


                        <!-- ngasih tau kalo ini form delete -->
                        <input type="hidden" name="_method" value="DELETE">

                        <button type="submit" class="btn btn-outline-danger btn-sm" active>delete</button>
                      </form>
                  </span>
                  <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>