@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-primary">
                <h2 class="card-header  text-white bg-primary">Berita Terbaru</h2>
                <div class="card-body">
                    @if (session('msg'))
                        <div class="alert alert-success">
                            {{ session('msg') }}
                        </div>
                    @elseif (session('redmsg'))
                        <div class="alert alert-danger">
                          {{session('redmsg')}}
                    </div>
                    @endif

                    @foreach ($announcements as $announcement)
                    <div>
                      <p style="text-align:right">
                        @if($announcement->baru())
                          <span class="badge badge-info">Berita Baru!</span>
                        @elseif($announcement->diubah())
                          <span class="badge badge-warning">Berita diperbarui!</span>
                        @endif
                        {{$announcement->updated_at}}
                      </p>
                      <h4  class="card-title text-center" >{{$announcement->judul}}</h4>
                      <p class="lead">{!!$announcement->konten!!}</p>
                      <hr>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
        <div class="col-md-3">
          <div class="card border-danger">
            <div class="card-header">
              <h3>Ini Isi Apaan Kek Biar Rame</h3>
            </div>
          </div>
        </div>
    </div>
</div>
@endsection
