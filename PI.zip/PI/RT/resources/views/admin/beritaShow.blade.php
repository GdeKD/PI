@extends('layouts.dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
              <br>
                <div class="card-header" style="text-align: center">
                  <h3>{{ $announcement->judul }}</h3>
                </div>
                <hr>
                <div class="card-body">
                  <p>{!! $announcement->konten !!}</p>
                  @if($announcement->owner())
                  <span>
                    <a href="/admin/berita/{{$announcement->id}}/edit" class="btn btn-outline-warning btn-sm btn-active">edit</a>
                  </span>
                  <span>
                      <form class="" action="{{$announcement->id}}" method="post">
                        {{ csrf_field() }}

                        <!-- ngasih tau kalo ini form delete -->
                        <input type="hidden" name="_method" value="DELETE">

                        <button type="submit" class="btn btn-outline-danger btn-sm" active>delete</button>
                      </form>
                  </span>
                  @endif

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
