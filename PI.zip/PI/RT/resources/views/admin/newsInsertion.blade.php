@extends('layouts.dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <br>
                <div class="card-header" style="text-align: center">{{ __('Form Pembuatan Berita') }}</div>
                <hr>
                <div class="card-body">
                  <!-- Form -->
                  <form class="" action="/admin/berita" method="post">
                    <div class="form-group">
                      <label for="title">Judul Berita</label>
                      <input type="text" name="title" class="form-control" placeholder="tulis judul di sini" value="{{old('title')}}">
                    </div>
                    <div class="form-group">
                      <label for="konten">Isi Berita</label>
                      <textarea id="WYSIWYG" name="konten" class="form-control" rows="8" cols="80">{{old('konten')}}</textarea>
                    </div>

                    {{ csrf_field() }}

                    <button type="submit" class="btn btn-default btn-block btn-outline-primary">Tampilkan Berita</button>
                  </form>
                  <!-- Form -->
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
